Tar is an archiving utility in Linux. Lets see how can we extract various archived files in Linux using this utility.  We will also see the meaning of the options provided with the commands. Type the following commands in terminal (Keyboard short cut: Ctrl+Alt+T in Ubuntu):

Extracting .tar.bz2:
tar xvjf filename.tar.bz2 location
Extracting .tar.gz:
tar xvzf filename.tar.gz location
Where:
x — extract

v — verbose (it will show the extracting files in the terminal)

f — file

z — gzip (or gz in short)

j — bzip2 (or bz2 in short)

location — location where you want to save the extracted the files. If you want to save it in the same directory where you have the zipped file use “.” in place of “location”.

All extracted files will be kept in a single directory automatically. The name of this directory is decided by the zipped file itself.